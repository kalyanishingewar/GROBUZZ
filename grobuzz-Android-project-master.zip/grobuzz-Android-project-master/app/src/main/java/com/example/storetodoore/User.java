package com.example.storetodoore;


public class User {
    public String fullname,email,house,area,landmark,mobile;

    public User (){

    }
    public User(String fullname,String email, String house, String area, String landmark, String mobile ){
        this.fullname =fullname;
        this.email = email;
        this.house = house;
        this.area = area;
        this.landmark = landmark;
        this.mobile= mobile;
    }
}
