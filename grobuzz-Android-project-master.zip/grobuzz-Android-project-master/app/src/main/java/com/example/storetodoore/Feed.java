package com.example.storetodoore;

public class Feed {
    public String User_Feedback;
    public Feed() {
    }

    public Feed(String feedback){
        this.User_Feedback= feedback;
    }



}
